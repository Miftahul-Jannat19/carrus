document.addEventListener("DOMContentLoaded", () => {
    const carModelSelect = document.getElementById("car-model");
    const carColorSelect = document.getElementById("car-color");
    const carPhoto = document.getElementById("car-photo");
    const carPriceElement = document.getElementById("car-price");
    const subscriptionDurationInput = document.getElementById("subscription-duration");
    const discountElement = document.getElementById("discount");
    const totalPriceElement = document.getElementById("total-price");
    const calculatePriceButton = document.getElementById("calculate-price");
    const subscribeNowButton = document.getElementById("subscribe-now");
    const clientEmail = document.getElementById("client-email");
    const clientLocation = document.getElementById("client-location");
  
    // Update car photo and price
    const updateCarPhoto = () => {
      const model = carModelSelect.value;
      const color = carColorSelect.value;
      carPhoto.src = `${model}-${color}.jpg`;
  
      const selectedOption = carModelSelect.options[carModelSelect.selectedIndex];
      const pricePerMonth = selectedOption.getAttribute("data-price");
      carPriceElement.textContent = `${pricePerMonth}tk`;
    };
  
    // Calculate total price with discount
    const calculateTotalPrice = () => {
      const selectedOption = carModelSelect.options[carModelSelect.selectedIndex];
      const pricePerMonth = parseFloat(selectedOption.getAttribute("data-price"));
      const duration = parseInt(subscriptionDurationInput.value, 10) || 1;
  
      let discount = 0;
      if (duration > 6) {
        discount = 0.1; // 10% discount
      }
  
      const totalPrice = pricePerMonth * duration * (1 - discount);
      discountElement.textContent = `${discount * 100}%`;
      totalPriceElement.textContent = `${totalPrice.toFixed(2)}tk`;
    };
  
    // Send subscription data to the backend
    const subscribeNow = async () => {
      const payload = {
        clientEmail: clientEmail.value,
        clientLocation: clientLocation.value,
        carModel: carModelSelect.value,
        carColor: carColorSelect.value,
        subscriptionDuration: parseInt(subscriptionDurationInput.value, 10),
        totalPrice: parseFloat(totalPriceElement.textContent)
      };
  
      try {
        const response = await fetch("http://localhost:8080/api/subscriptions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify(payload)
        });
  
        if (response.ok) {
          alert("Subscription successful!");
        } else {
          alert("Failed to subscribe. Please try again.");
        }
      } catch (error) {
        console.error("Error:", error);
        alert("An error occurred. Please try again.");
      }
    };
  
    carModelSelect.addEventListener("change", updateCarPhoto);
    carColorSelect.addEventListener("change", updateCarPhoto);
    calculatePriceButton.addEventListener("click", calculateTotalPrice);
    subscribeNowButton.addEventListener("click", (e) => {
      e.preventDefault();
      subscribeNow();
    });
  
    // Initialize car preview and price
    updateCarPhoto();
  });
  