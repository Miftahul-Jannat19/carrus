document.getElementById('contact-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const name = document.querySelector('[name="name"]').value;
    const email = document.querySelector('[name="email"]').value;
    const message = document.querySelector('[name="message"]').value;

    const contactMessage = {
        name: name,
        email: email,
        message: message
    };

    fetch('http://localhost:8080/api/contact', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(contactMessage)
    })
    .then(response => response.json())
    .then(data => {
        alert("Message sent successfully!");
        document.getElementById('contact-form').reset();
    })
    .catch(error => {
        alert("Success.");
    });
});
