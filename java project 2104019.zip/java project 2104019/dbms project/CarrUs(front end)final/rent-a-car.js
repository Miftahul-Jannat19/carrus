document.addEventListener("DOMContentLoaded", () => {
    const carModelSelect = document.getElementById("car-model");
    const carColorSelect = document.getElementById("car-color");
    const carPhoto = document.getElementById("car-photo");
    const carPriceElement = document.getElementById("car-price");
    const totalDaysInput = document.getElementById("total-days");
    const totalPriceElement = document.getElementById("total-price");
    const calculatePriceButton = document.getElementById("calculate-price");
  
    // Update car photo and price based on model and color
    const updateCarPhoto = () => {
      const model = carModelSelect.value;
      const color = carColorSelect.value;
  
      // Update car photo
      carPhoto.src = `${model}-${color}.jpg`; // Example: sedan-red.jpg
  
      // Update price per day
      const selectedOption = carModelSelect.options[carModelSelect.selectedIndex];
      const pricePerDay = selectedOption.getAttribute("data-price");
      carPriceElement.textContent = `${pricePerDay}`;
    };
  
    // Calculate total price with discount
    const calculateTotalPrice = () => {
      const selectedOption = carModelSelect.options[carModelSelect.selectedIndex];
      const pricePerDay = parseFloat(selectedOption.getAttribute("data-price"));
      const totalDays = parseInt(totalDaysInput.value, 10);
  
      if (isNaN(totalDays) || totalDays <= 0) {
        alert("Please enter a valid number of days.");
        totalDaysInput.focus();
        return;
      }
  
      const discount = 0.2; // 20% discount
      const originalPrice = pricePerDay * totalDays;
      const totalPrice = originalPrice * (1 - discount);
  
      totalPriceElement.textContent = `${totalPrice.toFixed(2)} (Discounted from ${originalPrice.toFixed(2)})`;
      totalPriceElement.style.color = "green"; // Highlight the total price
    };
  
    // Event listeners
    carModelSelect.addEventListener("change", updateCarPhoto);
    carColorSelect.addEventListener("change", updateCarPhoto);
    calculatePriceButton.addEventListener("click", calculateTotalPrice);
  
    // Initialize car preview and price on page load
    updateCarPhoto();
  });

  
  document.addEventListener("DOMContentLoaded", () => {
    const payNowButton = document.getElementById("pay-now");
  
    const handlePayNow = () => {
      const bookingData = {
        clientEmail: document.getElementById("client-email").value,
        carModel: document.getElementById("car-model").value,
        carColor: document.getElementById("car-color").value,
        pickUpLocation: document.getElementById("pick-up").value,
        dropOffLocation: document.getElementById("drop-off").value,
        pickUpDate: document.getElementById("pick-up-date").value,
        pickUpTime: document.getElementById("pick-up-time").value,
        totalDays: document.getElementById("total-days").value,
        totalPrice: parseFloat(document.getElementById("total-price").textContent)
      };
  
      fetch("http://localhost:8080/api/bookings", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(bookingData)
      })
        .then((response) => {
          if (response.ok) {
            alert("Booking successful!");
          } else {
            alert("Failed to book. Please try again.");
          }
        })
        .catch((error) => {
          console.error("Error:", error);
          alert("Error while booking.");
        });
    };
  
    payNowButton.addEventListener("click", handlePayNow);
  });
  