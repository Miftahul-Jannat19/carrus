document.querySelector('form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const paymentData = {
        paymentFrom: document.getElementById('paymentFrom').value,
        paymentMethod: document.getElementById('paymentMethod').value,
        paymentType: document.getElementById('paymentType').value,
        amount: parseFloat(document.getElementById('amount').value),
        transactionId: document.getElementById('transactionId').value,
        paymentDate: document.getElementById('paymentDate').value
    };

    try {
        const response = await fetch('http://localhost:8080/api/payments', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(paymentData)
        });

        if (response.ok) {
            alert('Payment saved successfully!');
        } else {
            const error = await response.json();
            console.error('Error:', error);
            alert('Error saving payment: ' + error.message);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Unable to connect to the server.');
    }
});
