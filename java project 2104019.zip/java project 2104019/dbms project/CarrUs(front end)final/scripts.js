// Function to handle user login
async function handleLogin() {
    // Get input values from the login form
    const email = document.getElementById("login-email").value;
    const password = document.getElementById("login-password").value;

    // Basic validation
    if (!email || !password) {
        alert("Please fill in all fields.");
        return;
    }

    try {
        // Call the backend API to authenticate the user
        const response = await fetch("http://localhost:8080/api/users/login", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ email, password }),
        });

        if (response.ok) {
            const data = await response.json();

            // Successful login
            alert("Login successful!");
            // Redirect to home page or perform further actions
            window.location.href = "./home.html";
        } else if (response.status === 401) {
            alert("Invalid email or password. Please try again.");
        } else {
            alert("Something went wrong. Please try again later.");
        }
    } catch (error) {
        console.error("Error logging in:", error);
        alert("An error occurred. Please try again later.");
    }
}

// Attach the login function to the button
document.querySelector("button").addEventListener("click", handleLogin);
