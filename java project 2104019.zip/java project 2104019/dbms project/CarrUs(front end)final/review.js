document.getElementById('review-form').addEventListener('submit', async (event) => {
    event.preventDefault(); // Prevent form from refreshing the page

    const email = document.querySelector('input[name="email"]').value;
    const review = document.querySelector('textarea[name="review"]').value;
    const rating = document.querySelector('select[name="rating"]').value;

    const reviewData = {
        email,
        review,
        rating: parseInt(rating)
    };

    try {
        const response = await fetch('http://localhost:8080/api/reviews', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(reviewData),
        });

        if (response.ok) {
            alert('Thank you for your review!');
            document.getElementById('review-form').reset();
        } else {
            alert('Error submitting your review. Please try again.');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Unable to connect to the server.');
    }
});
