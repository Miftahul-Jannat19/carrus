function registerUser() {
    const user = {
        name: document.getElementById("signup-name").value,
        phone: document.getElementById("signup-phone").value,
        email: document.getElementById("signup-email").value,
        address: document.getElementById("signup-address").value,
        nid: document.getElementById("signup-nid").value,
        dob: document.getElementById("signup-dob").value,
        gender: document.getElementById("signup-gender").value,
        userRole: document.getElementById("signup-userrole").value,
        password: document.getElementById("signup-password").value
    };

    fetch("http://localhost:8080/api/users/register", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(user),
    })
        .then((response) => {
            if (response.ok) {
                alert("User registered successfully!");
                window.location.href = "./login.html";
            } else {
                return response.text().then((text) => {
                    alert("Error: " + text);
                });
            }
        })
        .catch((error) => console.error("Error:", error));
}
