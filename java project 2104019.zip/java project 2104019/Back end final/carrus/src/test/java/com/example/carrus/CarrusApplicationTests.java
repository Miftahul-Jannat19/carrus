package com.example.carrus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarrusApplicationTests {

    @Test
    void contextLoads() {
    }

}
