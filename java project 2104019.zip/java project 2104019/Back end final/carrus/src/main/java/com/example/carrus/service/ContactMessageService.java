package com.example.carrus.service;

import com.example.carrus.model.ContactMessage;
import com.example.carrus.repository.ContactMessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ContactMessageService {

    @Autowired
    private ContactMessageRepository repository;

    public void saveContactMessage(ContactMessage contactMessage) {
        repository.save(contactMessage);
    }
}
