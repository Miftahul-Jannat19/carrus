package com.example.carrus.repository;

import com.example.carrus.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepositorylogin extends JpaRepository<User, Long> {
    User findByEmail(String email);
}
