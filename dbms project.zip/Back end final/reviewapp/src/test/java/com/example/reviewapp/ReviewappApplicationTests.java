package com.example.reviewapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReviewappApplicationTests {

    @Test
    void contextLoads() {
    }

}
