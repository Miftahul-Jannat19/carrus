package com.example.carrus.controller;

public @interface Valid {
}
