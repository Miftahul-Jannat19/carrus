package com.example.carrus.controller;

import com.example.carrus.model.ContactMessage;
import com.example.carrus.service.ContactMessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/contact")
@CrossOrigin(origins = "*")
public class ContactController {

    @Autowired
    private ContactMessageService contactMessageService;

    @PostMapping
    public ResponseEntity<String> submitContactMessage(@RequestBody ContactMessage contactMessage) {
        contactMessageService.saveContactMessage(contactMessage);
        return ResponseEntity.ok("Message submitted successfully!");
    }
}
