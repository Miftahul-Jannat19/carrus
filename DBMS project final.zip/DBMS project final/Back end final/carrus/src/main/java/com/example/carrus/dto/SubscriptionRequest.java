//package com.example.carrus.dto;
//
//import com.example.carrus.model.Subscription;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//
//@PostMapping
//public <SubscriptionRequest> Subscription createSubscription(@RequestBody Subscription request) {
//    System.out.println("Received subscription request: " + request);
//    SubscriptionRequest subscriptionService = null;
//    return subscriptionService.createSubscription(
//            request.getUser().getId(),
//            request.getCar().getId(),
//            request.getDuration(),
//            request.getTotalPrice(),
//            request.getLocation()
//    );
//}
//
//
