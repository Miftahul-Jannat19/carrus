//package com.example.carrus.dto;
//
//public class DriverInfoDTO {
//
//    private String licenseNumber;
//    private String userName;
//    private String userPhone;
//
//    // Constructor
//    public DriverInfoDTO(String licenseNumber, String userName, String userPhone) {
//        this.licenseNumber = licenseNumber;
//        this.userName = userName;
//        this.userPhone = userPhone;
//    }
//
//    // Getters and Setters
//    public String getLicenseNumber() {
//        return licenseNumber;
//    }
//
//    public void setLicenseNumber(String licenseNumber) {
//        this.licenseNumber = licenseNumber;
//    }
//
//    public String getUserName() {
//        return userName;
//    }
//
//    public void setUserName(String userName) {
//        this.userName = userName;
//    }
//
//    public String getUserPhone() {
//        return userPhone;
//    }
//
//    public void setUserPhone(String userPhone) {
//        this.userPhone = userPhone;
//    }
//}
