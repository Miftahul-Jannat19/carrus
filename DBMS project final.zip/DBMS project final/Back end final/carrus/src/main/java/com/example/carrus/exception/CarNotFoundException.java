//package com.example.carrus.exception;
//
//import org.springframework.http.HttpStatus;
//import org.springframework.web.bind.annotation.ResponseStatus;
//
//// This annotation automatically sets the response status to 404 (Not Found) when this exception is thrown
//@ResponseStatus(value = HttpStatus.NOT_FOUND)
//public class CarNotFoundException extends RuntimeException {
//
//    public CarNotFoundException(Long carId) {
//        super("Car with ID " + carId + " not found");
//    }
//}
